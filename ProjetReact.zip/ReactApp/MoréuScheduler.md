# Welcome to Moréu

Votre temps est précieux mais vous ne pouvez pas en perdre une seconde. Les gens ont besoin de vous voir parce que le travail doit être fait et qu'il y a des collaborations à faire. Au lieu de laisser les gens communiquer directement avec vous pour planifier leur utilisation de votre temps - ce qui ne fait que le gaspiller davantage - nous utiliserons Cosmic JS pour créer un planificateur de rendez-vous. De cette façon, les personnes qui ont besoin de vous parler n'ont à le faire qu'une seule fois.

Cosmic JS est un CMS basé sur l'API, ce qui signifie qu'il est indépendant du langage, de la base de données et pratiquement indépendant de tout le reste. C'est très bien pour un petit projet comme celui-ci car nous pouvons l'étendre rapidement avec n'importe quel langage ou framework à l'avenir et nous pouvons définir des structures de données aussi complexes que nous en avons besoin.

Notre planificateur de rendez-vous permettra aux utilisateurs de sélectionner un jour et un créneau horaire d'une heure entre 9h et 17h pour nous rencontrer. Nous intégrerons ensuite notre application à Twilio pour leur envoyer un SMS de confirmation que leur rendez-vous a été programmé. Enfin, nous allons créer une extension Cosmic JS afin de pouvoir gérer les rendez-vous directement depuis le tableau de bord Cosmic JS.

Nous réaliserons notre projet en 3 grandes sections :

1. Construire le front-end dans React et Webpack, à l'aide de la bibliothèque de composants Material UI
2. Le câbler à un simple backend Express qui servira à faire des appels d'API à Twilio et à exposer nos objets Rendez-vous au front-end (dans l'esprit de garder nos clés de compartiment Cosmic hors de notre code front-end)
3. Construire l'extension dans React, à nouveau en utilisant la bibliothèque Material UI



```

3. Ensuite, nous allons installer les packages dont nous avons besoin. D'intérêt, à côté de tous les packages standard nécessaires pour développer une application React dans ES6, nous utiliserons :

   -```async``` pour un moyen facile de passer des appels ajax en série
   - ```axios``` comme utilitaire ajax utile
   - ```babel-preset-stage-3``` pour utiliser le modèle de déstructuration ```const { property } = object```
   - ```material-ui``` pour un ensemble pratique de composants Material Design construits par React
   - ```moment``` pour les temps d'analyse
   - ```normalize.css``` pour effacer les styles par défaut du navigateur
   - ```react-tap-event-plugin``` - un compagnon nécessaire à ```material-ui```

  




   ```
 nous devons définir un point d'entrée pour notre application. Ici, nous importerons toutes les bibliothèques globales ou composants wrapper nécessaires. Nous l'utiliserons également comme point de rendu pour notre application React. Ce sera notre fichier ```src/index.js``` et il ressemblera à ceci 

```js
// ./src/index.js

import React from 'react'
import ReactDom from 'react-dom'
import App from './Components/App'
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider'

import 'normalize.css'

require('./scss/app.scss')

window.React = React

ReactDom.render(
  <MuiThemeProvider>
    <App />
  </MuiThemeProvider>,
  document.getElementById('root')
)

// MuiThemeProvider est un composant wrapper pour les composants de MaterialUI
```

###  Skeleton

Ayant tout en place pour faire fonctionner notre application, nous avons quelques éléments à considérer et quelques choix à faire sur la façon dont nous voulons que notre application fonctionne avant de commencer à la créer. Pour nous aider à réfléchir, nous allons construire un squelette de base de ce à quoi il doit ressembler :

```Jsx
// ./src/Components/App.js

import { Component } from 'react'
import injectTapEventPlugin from 'react-tap-event-plugin'

injectTapEventPlugin()

export default class App extends Component {
    constructor() {
    	super()
      	this.state = {
        }
        
    }
  
  
	componentWillMount() {
    }
  	componentWillUnmount() {
    }
  	render() {
      	return (
        	<div>
          	</div>
        )
    }
}
```



- L'application charge les données d'un serveur externe, il serait donc utile de montrer à nos utilisateurs quand cela se produit
- Material Design implémente une navigation de style tiroir, nous devons donc savoir quand c'est ouvert
- Pour confirmer les détails du rendez-vous de l'utilisateur avant de soumettre, nous lui montrerons un modal de confirmation et pour les autres notifications, nous utiliserons le snack-bar de Material Design, qui affiche de petites notifications en bas de la page. Nous devrons suivre l'état d'ouverture de ces deux éléments.
- Notre processus de prise de rendez-vous se déroulera en trois étapes : sélection d'une date, sélection d'un créneau horaire et saisie des informations personnelles. Nous devons savoir à quelle étape se trouve l'utilisateur, la date et l'heure qu'il a sélectionnées, ses coordonnées, et nous devons également valider son adresse e-mail et son numéro de téléphone.
- Nous allons charger des données de configuration et un planning de rendez-vous que nous gagnerions à mettre en cache dans l'état.
- Au fur et à mesure que notre utilisateur parcourt les 3 étapes de planification, nous afficherons une phrase amicale pour suivre sa progression. (Exemple : « Planifier un rendez-vous d'une heure à 15 h le… »). Nous devons savoir si cela doit être affiché.
- Lorsque l'utilisateur sélectionne un créneau de rendez-vous, il pourra filtrer par AM/PM, nous devons donc savoir lequel il recherche.
- Enfin, nous allons ajouter de la réactivité à notre style et nous devons garder une trace de la largeur de l'écran.





Nous avons défini un état initial pour notre application, mais avant de créer une vue avec les composants Material, nous trouverons utile de réfléchir à ce qui doit être fait avec nos données. Notre application se résumera aux fonctionnalités suivantes :

- Comme décidé à l'étape précédente, notre navigation sera dans un tiroir donc nous avons besoin d'une méthode ```handleNavToggle()``` pour l'afficher/cacher
- Les trois étapes de planification sont révélées successivement à l'utilisateur à la fin d'une étape précédente, nous avons donc besoin d'une méthode ```handleNextStep()``` pour gérer le flux d'entrée de l'utilisateur
- Nous utiliserons un sélecteur de date Material UI pour définir notre date de rendez-vous et nous avons besoin d'une méthode ```handleSetAppointmentDate()``` pour traiter les données de ce composant. De même, nous avons besoin d'une méthode ```handleSetAppointmentSlot()``` et ```handleSetAppointmentMeridiem()```. Nous ne voulons pas que le sélecteur de date affiche les jours indisponibles (y compris ```aujourd'hui```), nous devons donc lui passer une méthode ```checkDisableDate()```.
- Dans la méthode de cycle de vie ```componentWillMount()```, nous allons récupérer nos données depuis notre backend, puis gérer ces données avec une méthode séparée ```handleFetch()```. Pour une erreur de récupération, nous aurons besoin d'une méthode ```handleFetchError()```.
- Lors de la soumission des données de rendez-vous, nous utiliserons ```handleSubmit()``` pour les envoyer à notre backend. Nous aurons besoin d'une méthode ```validateEmail()``` et ```validatePhone()``` lorsque l'utilisateur remplit les informations de contact.
- La chaîne conviviale au-dessus du formulaire sera rendue dans une méthode distincte avec ```renderConfirmationString()```. Il en sera de même pour les heures de rendez-vous disponibles et le modal de confirmation avec respectivement ```renderAppointmentTimes()``` et ```renderAppointmentConfirmation()```.
- Enfin, nous utiliserons une méthode pratique ```resize()``` pour répondre au changement de largeur de la fenêtre du navigateur











En utilisant Cosmic JS, Twilio, Express et React, nous avons construit un planificateur de Reunions modulaire et facile à étendre pour donner aux autres un accès facile à notre temps tout en en économisant plus pour nous-mêmes. La vitesse à laquelle nous sommes en mesure de déployer notre application et la simplicité de gestion de nos données renforcent le fait que c'était un choix évident d'utiliser Cosmic JS à la fois pour le CMS et le déploiement. Bien que notre planificateur de rendez-vous nous fera certainement gagner du temps à l'avenir, il est certain qu'il ne pourra jamais rivaliser avec le temps que Cosmic nous fera gagner sur de futurs projets.

---

